package com.sosu.project

data class Quote(
    val quote: String,
    val name: String
)